package com.example.espelho

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import java.io.ByteArrayOutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicReference

// Captura a tela e transmite como vídeo (quadros JPEG) por um endereço
// do Wi-Fi que a TV abre no navegador.
class ScreenService : Service() {

    companion object {
        @Volatile var running = false
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var server: ServerSocket? = null
    private val frame = AtomicReference<ByteArray?>(null)
    @Volatile private var frameId = 0L
    @Volatile private var stopped = false
    private var lastMs = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        iniciarForeground()
        val code = intent.getIntExtra("code", 0)
        val data = intent.getParcelableExtra<Intent>("data")
        val modo = intent.getStringExtra("mode") ?: "normal"
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            parar()
            iniciar(code, data, modo)
        } catch (e: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun iniciarForeground() {
        val canal = "espelho"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(canal, "Espelho de Tela", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, canal)
            .setContentTitle("Espelhando a tela")
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun iniciar(code: Int, data: Intent, modo: String) {
        stopped = false
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mpm.getMediaProjection(code, data)
        projection = mp
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }, Handler(Looper.getMainLooper()))

        val dm = Resources.getSystem().displayMetrics
        val semDelay = modo == "sem"
        // Sem delay: imagem menor e leve, muitos quadros por segundo.
        // Com delay: imagem grande e nítida, menos quadros (filmes e séries).
        val escala = if (semDelay) 0.5f else 0.8f
        val qualidade = if (semDelay) 45 else 80
        val intervalo = if (semDelay) 33L else 66L
        val w = ((dm.widthPixels * escala).toInt() / 2) * 2
        val h = ((dm.heightPixels * escala).toInt() / 2) * 2

        val ht = HandlerThread("captura")
        ht.start()
        thread = ht
        val rd = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = rd
        rd.setOnImageAvailableListener({ r -> processar(r, w, h, qualidade, intervalo) }, Handler(ht.looper))
        display = mp.createVirtualDisplay(
            "espelho", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            rd.surface, null, null
        )
        iniciarServidor()
        running = true
    }

    private fun processar(r: ImageReader, w: Int, h: Int, qualidade: Int, intervalo: Long) {
        val img = r.acquireLatestImage() ?: return
        try {
            val agora = SystemClock.uptimeMillis()
            if (agora - lastMs < intervalo) return
            lastMs = agora
            val p = img.planes[0]
            val sobra = (p.rowStride - p.pixelStride * w) / p.pixelStride
            val bmp = Bitmap.createBitmap(w + sobra, h, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(p.buffer)
            val pronto = if (bmp.width != w) Bitmap.createBitmap(bmp, 0, 0, w, h) else bmp
            val out = ByteArrayOutputStream(64 * 1024)
            pronto.compress(Bitmap.CompressFormat.JPEG, qualidade, out)
            frame.set(out.toByteArray())
            frameId++
            if (pronto !== bmp) pronto.recycle()
            bmp.recycle()
        } finally {
            img.close()
        }
    }

    private fun iniciarServidor() {
        val ss = ServerSocket()
        ss.reuseAddress = true
        ss.bind(InetSocketAddress(PORTA))
        server = ss
        Thread {
            while (!stopped) {
                val c = try { ss.accept() } catch (e: Exception) { break }
                Thread { atender(c) }.start()
            }
        }.start()
    }

    private fun atender(c: Socket) {
        try {
            c.tcpNoDelay = true
            val entrada = c.getInputStream().bufferedReader()
            val linha = entrada.readLine() ?: return
            while (true) {
                val l = entrada.readLine() ?: break
                if (l.isEmpty()) break
            }
            val out = c.getOutputStream()
            val partes = linha.split(" ")
            val caminho = if (partes.size > 1) partes[1] else "/"
            if (caminho.startsWith("/stream")) {
                out.write(
                    ("HTTP/1.1 200 OK\r\n" +
                        "Content-Type: multipart/x-mixed-replace; boundary=frame\r\n" +
                        "Cache-Control: no-cache\r\n" +
                        "Connection: close\r\n\r\n").toByteArray()
                )
                out.flush()
                var ultimo = -1L
                while (!stopped) {
                    val f = frame.get()
                    if (f != null && frameId != ultimo) {
                        ultimo = frameId
                        out.write(
                            ("--frame\r\nContent-Type: image/jpeg\r\nContent-Length: " +
                                f.size + "\r\n\r\n").toByteArray()
                        )
                        out.write(f)
                        out.write("\r\n".toByteArray())
                        out.flush()
                    } else {
                        Thread.sleep(8)
                    }
                }
            } else {
                val corpo = ("<!doctype html><html><head><meta charset=\"utf-8\">" +
                    "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
                    "<title>Espelho de Tela</title></head>" +
                    "<body style=\"margin:0;background:#000\">" +
                    "<img src=\"/stream\" style=\"width:100vw;height:100vh;object-fit:contain\">" +
                    "</body></html>").toByteArray()
                out.write(
                    ("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n" +
                        "Content-Length: " + corpo.size + "\r\nConnection: close\r\n\r\n").toByteArray()
                )
                out.write(corpo)
                out.flush()
            }
        } catch (e: Exception) {
            // o aparelho fechou a conexão
        } finally {
            try { c.close() } catch (e: Exception) { }
        }
    }

    private fun parar() {
        stopped = true
        running = false
        try { server?.close() } catch (e: Exception) { }
        server = null
        try { display?.release() } catch (e: Exception) { }
        display = null
        try { reader?.close() } catch (e: Exception) { }
        reader = null
        try { projection?.stop() } catch (e: Exception) { }
        projection = null
        try { thread?.quitSafely() } catch (e: Exception) { }
        thread = null
        frame.set(null)
    }

    override fun onDestroy() {
        parar()
        super.onDestroy()
    }
}
