package com.example.espelho

import android.content.Context
import android.net.wifi.WifiManager
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.net.URL

// Procura TVs e aparelhos na rede Wi-Fi usando SSDP (o "chamado" que TVs
// Samsung, LG, Sony, Roku, Android TV e Chromecast respondem).
object Discovery {

    private val ALVOS = listOf(
        "urn:schemas-upnp-org:device:MediaRenderer:1",
        "urn:dial-multiscreen-org:service:dial:1",
        "roku:ecp"
    )

    fun scan(ctx: Context, tempoMs: Int = 4500): List<Dispositivo> {
        val wifi = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val lock = wifi.createMulticastLock("espelho")
        lock.setReferenceCounted(true)
        lock.acquire()
        val achados = LinkedHashMap<String, Dispositivo>()
        val meuIp = localIp()
        var socket: DatagramSocket? = null
        try {
            socket = DatagramSocket()
            socket.soTimeout = 700
            val grupo = InetAddress.getByName("239.255.255.250")
            for (rodada in 0 until 2) {
                for (alvo in ALVOS) {
                    val msg = ("M-SEARCH * HTTP/1.1\r\n" +
                        "HOST: 239.255.255.250:1900\r\n" +
                        "MAN: \"ssdp:discover\"\r\n" +
                        "MX: 2\r\n" +
                        "ST: " + alvo + "\r\n\r\n").toByteArray()
                    socket.send(DatagramPacket(msg, msg.size, grupo, 1900))
                }
            }
            val fim = System.currentTimeMillis() + tempoMs
            val buf = ByteArray(4096)
            while (System.currentTimeMillis() < fim) {
                try {
                    val pkt = DatagramPacket(buf, buf.size)
                    socket.receive(pkt)
                    val ip = pkt.address.hostAddress ?: continue
                    if (ip == meuIp || achados.containsKey(ip)) continue
                    val texto = String(pkt.data, 0, pkt.length)
                    val loc = Regex("(?im)^location:\\s*(.+)$").find(texto)?.groupValues?.get(1)?.trim()
                    val nome = if (loc != null) nomeDe(loc) else null
                    achados[ip] = Dispositivo(nome ?: ("Aparelho " + ip), ip)
                } catch (e: SocketTimeoutException) {
                    // segue esperando
                }
            }
        } catch (e: Exception) {
            // sem rede ou sem permissão: devolve o que achou
        } finally {
            try { socket?.close() } catch (e: Exception) { }
            lock.release()
        }
        return achados.values.toList()
    }

    private fun nomeDe(loc: String): String? {
        return try {
            val c = URL(loc).openConnection() as HttpURLConnection
            c.connectTimeout = 1200
            c.readTimeout = 1200
            val xml = c.inputStream.bufferedReader().use { it.readText() }
            Regex("<friendlyName>(.*?)</friendlyName>", RegexOption.DOT_MATCHES_ALL)
                .find(xml)?.groupValues?.get(1)?.trim()
        } catch (e: Exception) {
            null
        }
    }
}
