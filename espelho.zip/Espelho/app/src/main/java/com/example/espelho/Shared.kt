package com.example.espelho

import android.content.Context
import java.net.Inet4Address
import java.net.NetworkInterface

const val PORTA = 8080

data class Dispositivo(val nome: String, val ip: String)

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

// Endereço do celular no Wi-Fi (ou no hotspot)
fun localIp(): String? {
    try {
        var qualquer: String? = null
        val ifs = NetworkInterface.getNetworkInterfaces() ?: return null
        for (ni in ifs) {
            if (!ni.isUp || ni.isLoopback) continue
            for (a in ni.inetAddresses) {
                if (a is Inet4Address && !a.isLoopbackAddress) {
                    if (ni.name.startsWith("wlan") || ni.name.startsWith("ap")) return a.hostAddress
                    if (qualquer == null) qualquer = a.hostAddress
                }
            }
        }
        return qualquer
    } catch (e: Exception) {
        return null
    }
}
