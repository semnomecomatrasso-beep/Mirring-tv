package com.example.espelho

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var modo = "normal"
    private var alvo = Dispositivo("outro aparelho", "")
    private var scanId = 0

    private val pedirPermissoes =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { home() }

    private val pedirCaptura =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val data = res.data
            if (res.resultCode == RESULT_OK && data != null) {
                val i = Intent(this, ScreenService::class.java)
                i.putExtra("code", res.resultCode)
                i.putExtra("data", data)
                i.putExtra("mode", modo)
                startForegroundService(i)
                Handler(Looper.getMainLooper()).postDelayed({ transmitindo() }, 800)
            } else {
                toast("Sem a permissão de captura não dá para espelhar")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        home()
    }

    private fun toast(m: String) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    }

    // ---------- interface ----------

    private fun base(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.gravity = Gravity.CENTER_HORIZONTAL
        l.setPadding(dp(20), dp(48), dp(20), dp(24))
        return l
    }

    private fun show(col: LinearLayout) {
        val sv = ScrollView(this)
        sv.isFillViewport = true
        sv.addView(col)
        setContentView(sv)
    }

    private fun txt(t: String, size: Float, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.gravity = Gravity.CENTER
        v.setPadding(0, dp(8), 0, dp(8))
        if (bold) v.setTypeface(v.typeface, android.graphics.Typeface.BOLD)
        return v
    }

    private fun btn(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    // ---------- permissões ----------

    private fun necessarias(): List<String> {
        return if (Build.VERSION.SDK_INT >= 33) {
            listOf(Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.NEARBY_WIFI_DEVICES)
        } else {
            listOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    private fun concedida(p: String): Boolean =
        checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun faltando(): List<String> = necessarias().filter { !concedida(it) }

    private fun nomePermissao(p: String): String = when (p) {
        Manifest.permission.POST_NOTIFICATIONS -> "Notificações"
        Manifest.permission.NEARBY_WIFI_DEVICES -> "Dispositivos Wi-Fi por perto"
        else -> "Localização (o Android exige para procurar aparelhos no Wi-Fi)"
    }

    // ---------- telas ----------

    private fun home() {
        val l = base()
        l.addView(txt("Espelho de Tela", 26f, true))

        if (ScreenService.running) {
            l.addView(txt("📡 Espelhamento ativo", 18f))
            l.addView(btn("Ver endereço") { transmitindo() })
            l.addView(btn("■ Parar espelhamento") {
                stopService(Intent(this, ScreenService::class.java))
                toast("Espelhamento parado")
                Handler(Looper.getMainLooper()).postDelayed({ home() }, 400)
            })
        } else {
            l.addView(txt("Permissões", 18f, true))
            for (p in necessarias()) {
                l.addView(txt((if (concedida(p)) "✅ " else "⬜ ") + nomePermissao(p), 15f))
            }
            l.addView(txt("ℹ️ A captura de tela é pedida pelo Android na hora de conectar.", 13f))

            val falta = faltando()
            if (falta.isNotEmpty()) {
                l.addView(btn("Permitir tudo") { pedirPermissoes.launch(falta.toTypedArray()) })
                l.addView(btn("Continuar mesmo assim") { buscar() })
            } else {
                l.addView(btn("▶ Começar espelhamento") { buscar() })
            }
        }
        l.addView(btn("📺 Usar o Cast do Android (com som)") { abrirCast() })
        show(l)
    }

    private fun abrirCast() {
        try {
            startActivity(Intent(Settings.ACTION_CAST_SETTINGS))
        } catch (e: Exception) {
            toast("Abra a barra rápida e toque em Transmitir ou Smart View")
        }
    }

    private fun buscar() {
        val id = ++scanId
        val l = base()
        l.addView(txt("Procurando dispositivos…", 22f, true))
        l.addView(ProgressBar(this))
        l.addView(txt("Deixe a TV ligada e no mesmo Wi-Fi do celular.", 14f))
        l.addView(btn("Cancelar") {
            scanId++
            home()
        })
        show(l)
        Thread {
            val lista = Discovery.scan(this)
            runOnUiThread {
                if (id == scanId && !isFinishing) resultados(lista)
            }
        }.start()
    }

    private fun resultados(lista: List<Dispositivo>) {
        val l = base()
        l.addView(txt("Dispositivos encontrados", 22f, true))
        if (lista.isEmpty()) {
            l.addView(txt("Nenhuma TV encontrada. Confira se o celular e a TV estão no mesmo Wi-Fi e se a TV está ligada.", 14f))
        }
        for (d in lista) {
            l.addView(btn("📺 " + d.nome + "\n" + d.ip) { perguntarModo(d) })
        }
        l.addView(btn("🌐 Outro aparelho (navegador)") {
            perguntarModo(Dispositivo("outro aparelho", ""))
        })
        l.addView(btn("🔄 Procurar de novo") { buscar() })
        l.addView(btn("← Voltar") { home() })
        show(l)
    }

    private fun perguntarModo(d: Dispositivo) {
        AlertDialog.Builder(this)
            .setTitle("Conectar a " + d.nome)
            .setMessage(
                "Como você quer espelhar?\n\n" +
                    "• Sem delay: resposta rápida, imagem mais leve (jogos e apps).\n\n" +
                    "• Com delay: imagem maior e mais nítida (filmes e séries)."
            )
            .setPositiveButton("Sem delay") { _, _ -> iniciar(d, "sem") }
            .setNeutralButton("Com delay") { _, _ -> iniciar(d, "normal") }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun iniciar(d: Dispositivo, m: String) {
        alvo = d
        modo = m
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        pedirCaptura.launch(mpm.createScreenCaptureIntent())
    }

    private fun transmitindo() {
        val ip = localIp()
        val endereco = if (ip != null) "http://" + ip + ":" + PORTA else ""
        val l = base()
        l.addView(txt("📡 Espelhamento ativo", 24f, true))
        l.addView(txt("Dispositivo: " + alvo.nome, 15f))
        l.addView(txt("Modo: " + (if (modo == "sem") "Sem delay" else "Com delay"), 15f))
        if (ip == null) {
            l.addView(txt("Conecte o celular ao Wi-Fi para receber o endereço.", 16f))
        } else {
            l.addView(txt("Na TV (ou no outro aparelho), abra o navegador e digite:", 15f))
            val e = txt(endereco, 22f, true)
            e.setTextIsSelectable(true)
            l.addView(e)
            l.addView(btn("📋 Copiar endereço") {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("endereco", endereco))
                toast("Endereço copiado")
            })
        }
        l.addView(txt("Os dois aparelhos precisam estar no mesmo Wi-Fi. Este modo não envia o som do celular. Gire a tela do celular antes de começar se for ver na horizontal.", 13f))
        l.addView(btn("■ Parar espelhamento") {
            stopService(Intent(this, ScreenService::class.java))
            toast("Espelhamento parado")
            Handler(Looper.getMainLooper()).postDelayed({ home() }, 400)
        })
        l.addView(btn("← Início") { home() })
        show(l)
    }
}
